package teste;

public class Producao {
    int previsaoDemanda;
    int producaoNormal;
    int estoqueInicial;
    int estoqueFinal;    

    public Producao(int previsaoDemanda, int producaoNormal, int estoqueInicial) {
        this.previsaoDemanda = previsaoDemanda;
        this.producaoNormal = producaoNormal;
        this.estoqueInicial = estoqueInicial;
    }
    
    public void fazConta() {
        estoqueFinal = (estoqueInicial + producaoNormal) - previsaoDemanda;
    }
    
    public void status() {
        System.out.println("O estoque final previsto para o mês é de: " + estoqueFinal + "Unidades");
    }
}