package teste;

public class Teste {

    public static void main(String[] args) {
        Producao a1 = new Producao(200, 250, 50);
        a1.fazConta();
        a1.status();
    }
}
