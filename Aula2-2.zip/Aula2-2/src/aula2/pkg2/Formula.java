package aula2.pkg2;
public interface Formula {
   
    public abstract void soma();
    public abstract void result();
    
}
