package aula2.pkg2;
public class Aula22 {
    public static void main(String[] args) {
        ContaLogica c = new ContaLogica();
        c.soma();
        c.result();
    }
}
