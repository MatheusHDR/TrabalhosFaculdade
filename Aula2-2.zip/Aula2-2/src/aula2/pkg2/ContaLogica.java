package aula2.pkg2;
import javax.swing.JOptionPane;

public class ContaLogica implements Formula {
    //atributos
    private float base;
    private float altura;
    private float compriment;
/*
    public ContaLogica() {
        this.base = base;
        this.altura = altura;
        this.compriment = compriment;
    }
*/
    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public float getCompriment() {
        return compriment;
    }

    public void setCompriment(float compriment) {
        this.compriment = compriment;
    }
/*
    @Override
    public void valBase() {
        
    }

    @Override
    public void valAltura() {
        
    }

    @Override
    public void valCompriment() {
        
    }
*/
    @Override
    public void soma() {
        this.setBase(Float.parseFloat(JOptionPane.showInputDialog("Digite O valor da Base(cm): " )));
        this.setAltura(Float.parseFloat(JOptionPane.showInputDialog("Digite o valor da Altura(cm): ")));
        this.setCompriment(Float.parseFloat(JOptionPane.showInputDialog("Digite o valor do Comprimento(cm): ")));
    }
    
    @Override
    public void result() {
        JOptionPane.showMessageDialog(null, "O valor da Base x Altura x Comprimento é:" + this.getBase() * this.getAltura() * this.getCompriment());
    }

    
    
    
    
    
}
