package controle;
public class Controle {
    public static void main(String[] args) {
        Principal c1 = new Principal("22233344456", "Fulano de Tal", "Rua Dos Santos", 998653289, "Cliente@email.com");
       
        Modelo v1 = new Modelo("MTD9616", "Voyage", 2010, "Volkswagen", "Prata");
        
         c1.status();
         System.out.println(" ");
         v1.status();
    }
    
    
}
