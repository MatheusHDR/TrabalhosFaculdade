package controle;
public class Principal {
    private String cpf;
    private String nome;
    private String end;
    private int telefone;
    private String email;
    

    public Principal(String cpf, String nome, String end, int telefone, String email) {
        this.setCpf(cpf);
        this.setNome(nome);
        this.setEnd(end);
        this.setTelefone(telefone);
        this.setEmail(email);
    }
    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
  
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
    public void status() {
        System.out.println("CPF: " + this.cpf);
        System.out.println("Cliente: " + this.nome);
        System.out.println("Mora no Endereço: " + this.end);
        System.out.println("Num. de Telefone: " + this.telefone);
        System.out.println("Email do aluno: " + this.email);
    }
    
}
