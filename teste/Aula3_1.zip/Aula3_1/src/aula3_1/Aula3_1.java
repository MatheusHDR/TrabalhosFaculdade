package aula3_1;
public class Aula3_1 {
    public static void main(String[] args) {
        Veiculopasseio c1 = new Veiculopasseio();
        c1.pegaDados();
        System.out.println(c1.toString());
        
        Veiculocarga v2 = new Veiculocarga();
        v2.pegaDados();
        System.out.println(v2.toString());
    }
    
}
