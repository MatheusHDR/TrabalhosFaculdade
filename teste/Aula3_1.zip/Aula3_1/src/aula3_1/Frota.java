package aula3_1;
import javax.swing.JOptionPane;
public abstract class Frota {
    protected String especie;
    protected String placa;
    protected String procedencia;
    protected String marca;
    protected String modelo;
    protected String anomod;
    protected String datafab;
    protected String chassi;
    protected String renavam;
    protected String cor;
    protected String corintern;
    protected String combust;
    protected String motor;
    protected float km;
    protected String medconsumo;
    protected int portas;
    protected int passageiros;
    protected String opcionais;

    public void pegaDados() {
        this.setEspecie(JOptionPane.showInputDialog("Digite a espécie do veículo (Passeio/carga): "));
        this.setPlaca(JOptionPane.showInputDialog("Digite a placa do Veículo :"));
        this.setProcedencia(JOptionPane.showInputDialog("Digite a Procedência :"));
        this.setMarca(JOptionPane.showInputDialog("Digite o modelo do veículo: "));
        this.setAnomod(JOptionPane.showInputDialog("Digite o ano do modelo: "));
        this.setDatafab(JOptionPane.showInputDialog("Digite a data de Fabricação :"));
        this.setChassi(JOptionPane.showInputDialog("Digite o Chassi do veículo: "));
        this.setRenavam(JOptionPane.showInputDialog("Digite o renavam : "));
        this.setCor(JOptionPane.showInputDialog("Digite a cor do veículo :"));
        this.setCorintern(JOptionPane.showInputDialog("Digite a cor interna do veículo: "));
        this.setCombust(JOptionPane.showInputDialog("Digite o combustivel utilizado"));
        this.setMotor(JOptionPane.showInputDialog("Digite o nome/codigo do motor: "));
        this.setKm(Float.parseFloat(JOptionPane.showInputDialog("digite a quilometragem do veículo: ")));
        this.setMedconsumo(JOptionPane.showInputDialog("Digite o consumo médio: "));
        this.setPortas(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de portas: ")));
        this.setPassageiros(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de passageiros: ")));
        this.setOpcionais(JOptionPane.showInputDialog("Digite os opcionais caso haja"));      
    }

    @Override
    public String toString() {
        return "Frota" + "\n especie = " + especie + "\n placa = " + placa + "\n procedencia = " + procedencia + "\n marca = " + marca + "\n modelo = " + modelo + "\n anomod = " + anomod + "\n datafab = " + datafab + "\n chassi = " + chassi + "\n renavam = " + renavam + "\n cor = " + cor + "\n corintern = " + corintern + "\n combust = " + combust + "\n motor = " + motor + "\n km = " + km + "\n medconsumo = " + medconsumo + "\n portas = " + portas + "\n passageiros = " + passageiros + "\n opcionais = " + opcionais;
    }
    
    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }
   
    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getProcedencia() {
        return procedencia;
    }

    public void setProcedencia(String procedencia) {
        this.procedencia = procedencia;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getAnomod() {
        return anomod;
    }

    public void setAnomod(String anomod) {
        this.anomod = anomod;
    }

    public String getDatafab() {
        return datafab;
    }

    public void setDatafab(String datafab) {
        this.datafab = datafab;
    }

    public String getChassi() {
        return chassi;
    }

    public void setChassi(String chassi) {
        this.chassi = chassi;
    }

    public String getRenavam() {
        return renavam;
    }

    public void setRenavam(String renavam) {
        this.renavam = renavam;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getCorintern() {
        return corintern;
    }

    public void setCorintern(String corintern) {
        this.corintern = corintern;
    }

    public String getCombust() {
        return combust;
    }

    public void setCombust(String combust) {
        this.combust = combust;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    public float getKm() {
        return km;
    }

    public void setKm(float km) {
        this.km = km;
    }

    public String getMedconsumo() {
        return medconsumo;
    }

    public void setMedconsumo(String medconsumo) {
        this.medconsumo = medconsumo;
    }

    public int getPortas() {
        return portas;
    }

    public void setPortas(int portas) {
        this.portas = portas;
    }

    public int getPassageiros() {
        return passageiros;
    }

    public void setPassageiros(int passageiros) {
        this.passageiros = passageiros;
    }

    public String getOpcionais() {
        return opcionais;
    }

    public void setOpcionais(String opcionais) {
        this.opcionais = opcionais;
    }
}
