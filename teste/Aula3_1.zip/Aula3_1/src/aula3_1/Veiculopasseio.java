package aula3_1;
public class Veiculopasseio extends Frota {
    
}
