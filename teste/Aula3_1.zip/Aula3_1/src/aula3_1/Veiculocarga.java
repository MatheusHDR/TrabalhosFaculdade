package aula3_1;
import javax.swing.JOptionPane;
public class Veiculocarga extends Frota {
    private float capacidade;
    private float alt;
    private float larg;
    private float profund;

    public void pegarDados() {
    this.setCapacidade(Float.parseFloat(JOptionPane.showInputDialog("Digite a capacidade de carga: ")));
    this.setAlt(Float.parseFloat(JOptionPane.showInputDialog("Digite a altura(m): ")));
    this.setLarg(Float.parseFloat(JOptionPane.showInputDialog("Digite a largura(m): ")));
    this.setProfund(Float.parseFloat(JOptionPane.showInputDialog("Digite a profundidade (m): ")));
}
            
    public float getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(float capacidade) {
        this.capacidade = capacidade;
    }

    public float getAlt() {
        return alt;
    }

    public void setAlt(float alt) {
        this.alt = alt;
    }

    public float getLarg() {
        return larg;
    }

    public void setLarg(float larg) {
        this.larg = larg;
    }

    public float getProfund() {
        return profund;
    }

    public void setProfund(float profund) {
        this.profund = profund;
    }
    
    
}
